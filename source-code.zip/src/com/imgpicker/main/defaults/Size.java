package com.imgpicker.main.defaults;

public class Size {
 public static final int WIDTH = 900;
  public static final int HEIGHT = 800;
}
