package com.imgpicker.main.defaults;

import java.awt.Color;

public class Colorizer {
  private Colorizer() {}
  public static final Color FOREGROUND_ORANGE = new Color(247, 170, 69);
  public static final Color BACKGROUND_GRAY = new Color(56 , 56 , 56);
}
